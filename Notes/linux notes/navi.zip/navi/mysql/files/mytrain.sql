-- create new database
--
create database if not exists train
;
-- create new database user
--
grant select,insert,update on train.*
to 'user1'@'localhost' identified by 'user1'
;
show grants for 'user1'@'localhost'
;

