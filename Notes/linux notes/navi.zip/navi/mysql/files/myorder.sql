USE train;
DROP TABLE IF EXISTS saleline;
DROP TABLE IF EXISTS saleord;
DROP TABLE IF EXISTS product;
DROP TABLE IF EXISTS supplier;

CREATE TABLE product
(prdid		CHAR(3)	NOT NULL
    			PRIMARY KEY,
 descr		VARCHAR(30)	NOT NULL,
 cost			DECIMAL(6,2)	NOT NULL,
 sell			DECIMAL(6,2)	NOT NULL,
 instock		INTEGER	DEFAULT 0)
;

CREATE TABLE supplier
(supid		CHAR(4)	NOT NULL
    			PRIMARY KEY,
 name			VARCHAR(30)	NOT NULL,
 addr1		VARCHAR(30),
 addr2		VARCHAR(30),
 town			VARCHAR(30),
 county		VARCHAR(30),
 postcode		VARCHAR(8)	NOT NULL,
 credit		CHAR(1)	DEFAULT 'A')
;

CREATE TABLE saleord
(ordid		INTEGER	NOT NULL
    			PRIMARY KEY,
 supid		CHAR(4)	NOT NULL,
 dateOrd		DATETIME	NOT NULL,
 dateDue		DATETIME,
 comp			CHAR(1))
;

CREATE TABLE saleline
(ordid		INTEGER	NOT NULL,
 prdid		CHAR(3)	NOT NULL,
 qty			DECIMAL	NOT NULL,
 recd		CHAR(1)	DEFAULT 'N',
	FOREIGN KEY (OrdID) REFERENCES Saleord(OrdID),
	FOREIGN KEY (PrdID) REFERENCES product(PrdID),
	PRIMARY KEY (OrdID, PrdID))
;
--
--  INSERT VALUES INTO product TABLE
--  --------------------------------

INSERT INTO product VALUES(
'DR2','Iomega Zip Disc x 3',20,24.55,NULL
);
INSERT INTO product VALUES(
'FU1','Canon Multipass C50',540.25,634.79,1
);
INSERT INTO product VALUES(
'BK1','A Guide to SQL',14.5,18.56,20
);
INSERT INTO product VALUES(
'DR1','Iomega Zip Drive - 100 MB',93,118.11,10
);
INSERT INTO product VALUES(
'FU2','Hewlett Packard Officejet 700',367.5,459.38,2
);
INSERT INTO product VALUES(
'KB1','Canon Keyboard',23.5,29.61,25
);
INSERT INTO product VALUES(
'TW1','Patriot 200 MHz Tower',450.5,563.13,19
);
INSERT INTO product VALUES(
'KB2','Microsoft Keyboard',47.5,60.8,37
);
INSERT INTO product VALUES(
'LT3','IBM Thinkpad I',1093,1289.74,2
);
INSERT INTO product VALUES(
'KB3','Logitec Cordless Keyboard',50,64,NULL
);
INSERT INTO product VALUES(
'LT2','LG Phenom 100% Express',479,581.56,10
);
INSERT INTO product VALUES(
'LT1','Hewlett Packard Jornada 820e',665,822.12,1
);
INSERT INTO product VALUES(
'TW2','Olivetti 166 MHz Tower',375,480,10
);
INSERT INTO product VALUES(
'BK2','Access Database Design',20.6,25.75,30
);
INSERT INTO product VALUES(
'CA1','Kodak DC220 Zoom Camera',391.1,486.92,5
);
INSERT INTO product VALUES(
'LT4','Fujitsu Lifebook C325',827,1049.6,3
);
INSERT INTO product VALUES(
'MM1','Mouse Mat - Wallace & Gromit',8.2,10.5,60
);
INSERT INTO product VALUES(
'MM2','mouse Mat _ Plain',4.75,6.08,90
);
INSERT INTO product VALUES(
'MO2','Taxan Ergovision 550 15"',200,256,NULL
);
INSERT INTO product VALUES(
'MO3','CTX 17* Monitor',240,300,14
);
INSERT INTO product VALUES(
'MO1','Taxan Ergovision 735 17*',250,320,8
);
INSERT INTO product VALUES(
'MU1','Logitec Cordless Mouse',45.75,56.96,50
);
INSERT INTO product VALUES(
'MU2','Logitec Wheel MOUSE',20,25.4,55
);
INSERT INTO product VALUES(
'MU3','Canon''s Cruise Internet Pad',66,81.02,18
);
INSERT INTO product VALUES(
'PR1','CANON''s BJC_4200 Printer',150,176.25,9
);
INSERT INTO product VALUES(
'PR2','Epson''s Stylus Color 740',174.5,218.13,12
);
INSERT INTO product VALUES(
'PR3','Epson''s 300 Color Inkjet',125,157.5,12
);
INSERT INTO product VALUES(
'SC2','Hewlett Packards Scanjet 4100C',137,175.36,6
);
INSERT INTO product VALUES(
'SC1','Canon Genius Scanner',99.99,127.99,NULL
);
INSERT INTO product VALUES(
'SC3','Umax''s Astra 122OU Scanner',100,128,12
);
INSERT INTO product VALUES(
'SC4','Canon''s Snapscan 1212U',128,163.84,10
);
INSERT INTO product VALUES(
'TW3','Mesh Connect Ultra 350MHz',500,610,3
);
--
--  INSERT VALUES INTO supplier TABLE
--  ---------------------------------

INSERT INTO supplier VALUES(
'COMT','Comet Ltd',NULL,'Clifton Moor','York',NULL,'Y01 2AB','A'
);
INSERT INTO supplier VALUES(
'DELL','Dell Computers','Millbank House','Western Road','Bracknell',
'Berks','RG2 1HD','B'
);
INSERT INTO supplier VALUES(
'DIXN','Dixons Ltd','36 Coney Street',NULL,'Bath',NULL,'BA2 1GZ','A'
);
INSERT INTO supplier VALUES(
'PCWD','P C World','Monks Cross',NULL,'Bath',NULL,'BA2 1DC','A'
);
INSERT INTO supplier VALUES(
'TINY','Tiny Computers','3 Colliergate',NULL,'York',NULL,'Y01 3EX','B'
);
INSERT INTO supplier VALUES(
'CMAN','Computer Manuals',NULL,'Main Street','Birmingham',NULL,'B27 6BR','C'
);
INSERT INTO supplier VALUES(
'GATE','Gateway Computers','10 Bedford Street','Covent Garden','London',
NULL,'WC13 1CV','C'
);
INSERT INTO supplier VALUES(
'EVES','Evesham Vale','Gloucester Court','Gloucester Terrace','Leeds',
'West Yorkshire','LS12 4GB','A'
);
INSERT INTO supplier VALUES(
'ORBT','Orbit Computers','Gloucester Place','Gloucester Terrace','London',
NULL,'WC14 3DH','D'
);
--
--  INSERT VALUES INTO saleord TABLE
--  --------------------------------

INSERT INTO saleord VALUES(
100,'COMT',STR_TO_DATE('12/01/12','%d/%m/%Y'),STR_TO_DATE('11/02/12','%d/%m/%Y'),'Y'
);
INSERT INTO saleord VALUES(
101,'DIXN',STR_TO_DATE('24/01/12','%d/%m/%Y'),STR_TO_DATE('21/02/12','%d/%m/%Y'),'Y'
);
INSERT INTO saleord VALUES(
102,'DIXN',STR_TO_DATE('03/09/11','%d/%m/%Y'),STR_TO_DATE('15/09/11','%d/%m/%Y'),'Y'
);
INSERT INTO saleord VALUES(
103,'CMAN',STR_TO_DATE('02/11/11','%d/%m/%Y'),STR_TO_DATE(NULL,'%d/%m/%Y'),'N'
);
INSERT INTO saleord VALUES(
104,'EVES',STR_TO_DATE('23/09/11','%d/%m/%Y'),STR_TO_DATE(NULL,'%d/%m/%Y'),NULL
);
INSERT INTO saleord VALUES(
105,'TINY',STR_TO_DATE('08/01/12','%d/%m/%Y'),STR_TO_DATE(NULL,'%d/%m/%Y'),'N'
);
INSERT INTO saleord VALUES(
106,'DELL',STR_TO_DATE('12/04/12','%d/%m/%Y'),STR_TO_DATE('07/05/12','%d/%m/%Y'),'Y'
);
INSERT INTO saleord VALUES(
107,'CMAN',STR_TO_DATE('17/04/12','%d/%m/%Y'),STR_TO_DATE('18/05/12','%d/%m/%Y'),'Y'
);
INSERT INTO saleord VALUES(
108,'PCWD',STR_TO_DATE('02/02/12','%d/%m/%Y'),STR_TO_DATE(NULL,'%d/%m/%Y'),'N'
);
INSERT INTO saleord VALUES(
110,'CMAN',STR_TO_DATE('03/01/12','%d/%m/%Y'),STR_TO_DATE(NULL,'%d/%m/%Y'),NULL
);
INSERT INTO saleord VALUES(
109,'COMP',STR_TO_DATE('03/02/12','%d/%m/%Y'),STR_TO_DATE(NULL,'%d/%m/%Y'),NULL
);
--
UPDATE saleord SET datedue = STR_TO_DATE('07/05/12 11:30', '%d/%m/%Y %h:%i') WHERE ordid = 106
;
UPDATE saleord SET datedue = STR_TO_DATE('18/05/12 10:45', '%d/%m/%Y %h:%i') WHERE ordid = 107
;
--
--  INSERT VALUES INTO saleline TABLE
--  ---------------------------------

INSERT INTO saleline VALUES(
100,'KB3',55,'Y'
);
INSERT INTO saleline VALUES(
100,'SC2',35,'Y'
);
INSERT INTO saleline VALUES(
101,'DR1',1,NULL
);
INSERT INTO saleline VALUES(
101,'DR2',2,NULL
);
INSERT INTO saleline VALUES(
101,'KB3',1,NULL
);
INSERT INTO saleline VALUES(
101,'MO3',1,NULL
);
INSERT INTO saleline VALUES(
101,'MU1',1,NULL
);
INSERT INTO saleline VALUES(
101,'PR2',1,NULL
);
INSERT INTO saleline VALUES(
101,'SC2',1,NULL
);
INSERT INTO saleline VALUES(
101,'TW1',1,NULL
);
INSERT INTO saleline VALUES(
103,'TW1',20,'Y'
);
INSERT INTO saleline VALUES(
104,'FU1',5,'N'
);
INSERT INTO saleline VALUES(
104,'LT1',6,'N'
);
INSERT INTO saleline VALUES(
104,'SC2',25,'N'
);
INSERT INTO saleline VALUES(
105,'KB3',6,'N'
);
INSERT INTO saleline VALUES(
105,'TW1',12,'N'
);
INSERT INTO saleline VALUES(
105,'MU3',2,'N'
);
INSERT INTO saleline VALUES(
105,'DR1',20,'N'
);
INSERT INTO saleline VALUES(
105,'PR3',25,'N'
);
INSERT INTO saleline VALUES(
107,'BK1',10,NULL
);
INSERT INTO saleline VALUES(
107,'BK2',15,NULL
);
INSERT INTO saleline VALUES(
108,'MO1',100,'Y'
);
INSERT INTO saleline VALUES(
108,'MO3',250,'Y'
);

