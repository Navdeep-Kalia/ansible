import com.conygre.ejb.*;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
public class BookClient
{

	public static void main(String[] args)
	{
		try
		{
			// TO DO put your code here to look up the EJB and use it
		}
		catch (javax.naming.NamingException e)
		{
			System.out.println("Naming exception " + e);
		}



	}




}