package com.aviva.cdi;

public interface Steerable {
	
	void turnLeft();
	void turnRight();

}
