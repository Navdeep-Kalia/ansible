package com.conygre.beans;

public interface Vehicle {
	
	void move();

}
