package com.conygre.jee.ejb.timer;

import javax.ejb.Remote;
import javax.ejb.Timer;

@Remote 
public interface TimerExample {	
	    void goTimer(Timer t);
}
