package com.conygre.cdi.trl;

import javax.enterprise.inject.Alternative;

@Alternative
public class Mole implements Pet{

	@Override
	public void stroke() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bathe() {
		// TODO Auto-generated method stub
		
	}

}
