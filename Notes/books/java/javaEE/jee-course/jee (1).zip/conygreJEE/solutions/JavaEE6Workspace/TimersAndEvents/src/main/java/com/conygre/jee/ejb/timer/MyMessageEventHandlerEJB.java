package com.conygre.jee.ejb.timer;

import javax.ejb.Stateless;
import javax.enterprise.event.Observes;

@Stateless
public class MyMessageEventHandlerEJB implements MyMessageEventHandler {
	    /* (non-Javadoc)
		 * @see com.conygre.jee.ejb.timer.MyMessageEventHandler#handleTheMessage(com.conygre.jee.ejb.timer.MyMessageEvent)
		 */
	    @Override
		public void handleTheMessage(@Observes MyMessageEvent messageEvent){

	        System.out.println("Got a MyMessageEvent: " + messageEvent.getMessage());

	    }
	

}
