package com.conygre.jee.ejb.timer;
public class MyMessageEvent {

	private String message;

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
