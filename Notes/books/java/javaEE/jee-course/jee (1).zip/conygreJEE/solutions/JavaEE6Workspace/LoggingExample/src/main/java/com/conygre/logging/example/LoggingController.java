package com.conygre.logging.example;

import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

/**
 * This logging example works in conjunction with the logging configuration in standalone.xml
 * It does not work with Log4J.
 */


@Path("/log")
public class LoggingController {

	static Logger logger = Logger.getLogger("com.conygre.logger");
	
	@GET
	public String logGet() {
		logger.info("received a get request");

		return "logger triggered";
	}
	
	
}
