package com.conygre.beans;

public interface Printable {
	void printText(String s);

}
