package com.conygre.jee.service;

import com.conygre.training.entities.CompactDiscList;

public interface CompactDiscService {
	
	 CompactDiscList getAllProducts() ;

}
