package com.emc.cdi;

public interface Pet {
	
	void stroke();
	void feed();
	

}
