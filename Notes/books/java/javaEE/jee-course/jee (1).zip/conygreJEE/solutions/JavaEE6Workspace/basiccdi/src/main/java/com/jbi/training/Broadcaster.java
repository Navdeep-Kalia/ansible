package com.jbi.training;

public interface Broadcaster {
	
	void broadcast();

}
