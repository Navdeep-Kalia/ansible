package com.conygre.jee.ejb.timer;

import javax.ejb.Local;
import javax.enterprise.event.Observes;
@Local
public interface MyMessageEventHandler {

	void handleTheMessage(@Observes MyMessageEvent messageEvent);

}