package com.conygre.cdi.trl;

public interface Pet {
	
	void stroke();
	void bathe();

}
