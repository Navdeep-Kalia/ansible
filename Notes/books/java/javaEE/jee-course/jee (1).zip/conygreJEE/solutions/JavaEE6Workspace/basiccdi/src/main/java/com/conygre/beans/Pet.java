package com.conygre.beans;

public interface Pet {
	
	void stroke();

}
