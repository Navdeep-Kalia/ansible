package com.citi.cdi;

public interface Engine {

	void run();
	
}
