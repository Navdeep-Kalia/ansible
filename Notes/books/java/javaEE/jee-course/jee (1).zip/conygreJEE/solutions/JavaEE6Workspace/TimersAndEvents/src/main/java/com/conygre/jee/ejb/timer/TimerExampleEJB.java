package com.conygre.jee.ejb.timer;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.ejb.AccessTimeout;
import javax.ejb.Schedule;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.enterprise.event.Event;
import javax.inject.Inject;

@Stateless
public class TimerExampleEJB implements TimerExample {

	@Inject
	Event<MyMessageEvent> events;
	
	
	@Schedule(second = "*/1", minute = "*", hour = "*", year = "*", persistent = false)
	@Timeout
	@AccessTimeout(value = 5, unit = TimeUnit.SECONDS)
	public void goTimer(Timer timer) {
		// do some stuff on a time interval
		System.out.println("Timer fired and event created");
		MyMessageEvent message = new MyMessageEvent();
		message.setMessage("hello from the event " + new Date());
		events.fire(message);

	}
}
