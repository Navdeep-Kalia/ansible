package com.conygre.jee.service;

import com.conygre.training.entities.CompactDiscList;

public class CompactDiscServiceFake implements CompactDiscService{
	
	public CompactDiscList getAllProducts() {
		return null;
	}

}
